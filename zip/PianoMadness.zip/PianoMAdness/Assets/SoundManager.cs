using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SoundManager : MonoBehaviour
{
    public List<AudioSource> audioSources = new List<AudioSource>();
    public List<KeyCode> inputs = new List<KeyCode>();
    private IEnumerator previewInstance;




    public void PlayAudio(int audioListIndex)
        {
        audioSources[audioListIndex].Play();
        }

    public void Update()
    {
        for (int i = 0; i < inputs.Count; i++)
        {
            if (Input.GetKeyDown(inputs[i]))
            {
                audioSources[i].Play();
            }
        }
    }

    public void PlayPreview()
        {
        previewInstance = Preview();
        StartCoroutine(previewInstance);
    }

    public void StopPreview()
    {
        StopCoroutine(previewInstance);
    }

    private IEnumerator Preview()
    {
        audioSources[0].Play();
        yield return new WaitForSeconds(0.55f);
        audioSources[1].Play();
        yield return new WaitForSeconds(0.55f);
        audioSources[2].Play();
        yield return new WaitForSeconds(0.55f);
        audioSources[3].Play();
        yield return new WaitForSeconds(0.55f);
        audioSources[6].Play();
        yield return new WaitForSeconds(0.55f);
        audioSources[5].Play();
        yield return new WaitForSeconds(0.55f);
        audioSources[1].Play();
        yield return new WaitForSeconds(0.55f);
        audioSources[7].Play();
    }
}
