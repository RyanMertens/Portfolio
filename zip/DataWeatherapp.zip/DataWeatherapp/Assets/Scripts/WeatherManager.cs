using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using UnityEngine;

public class WeatherManager : MonoBehaviour
{
    public GameObject sunIcon;
    public GameObject rainDropIcon;
    public GameObject SnowIcon;

    public List<Weather> weathers = new List<Weather>();

    public List<GameObject> spawnedIcons = new List<GameObject>();

    private void Start()
    {
        //Weather currentWeather = new Weather("Eindhoven", 0.5f, 1);
        //Weather yesterdayWeather = new Weather("Wessem", 1.0f, 2);
        //weathers.Add(currentWeather);
        //weathers.Add(yesterdayWeather);
        ReadCSVFile();


        //dDraw(yesterdayWeather);

    }
    public void Draw(Weather renderedWeather)
    {
        //spawn icons
        CleanUpPreviousWeather();
        
        //spawn sun icon
        GameObject sunTemp = Instantiate(sunIcon, new Vector3(3, 3, 0), Quaternion.identity);
        sunTemp.transform.localScale = new Vector3(renderedWeather.sunPower, renderedWeather.sunPower, 1);
        spawnedIcons.Add(sunTemp);
        
        

        //spawn of raindrops
        for (int i = 0; i < renderedWeather.rain; i++)
        {
            GameObject rainDrop = Instantiate(rainDropIcon, new Vector3(2 + i, 1, 0), Quaternion.identity);
            spawnedIcons.Add(rainDrop); 
        }

        for (int i = 0; i < renderedWeather.Snow; i++)
        {
            GameObject Snow = Instantiate(SnowIcon, new Vector3(4 + i, 0, 2), Quaternion.identity);
            spawnedIcons.Add(Snow);
        }
    }


    public void OnClicked(int i)
    {
        if (weathers.Count >i)
        {
            Draw(weathers[i]);
           
        }
        else
        {
            Debug.Log("This weather is missing!");
        }
       
    }

    public void CleanUpPreviousWeather()
    {
        foreach (GameObject icon in spawnedIcons)
        {
            Destroy(icon);
        }
        spawnedIcons = new List<GameObject>();
    }

    public void ReadCSVFile()
    {
        StreamReader strReader = new StreamReader("C:\\Users\\merte\\Desktop\\DataWeatherapp\\Assets\\weatherData.CSV");
        bool endOfFile = false;
        while (!endOfFile)
        {
            string data_String = strReader.ReadLine();
            if (data_String == null)
            {
                endOfFile = true;
                break;
            }
            var data_values = data_String.Split(',');

            Debug.Log(data_values[0].ToString() + " " + data_values[1] + " " + data_values[2].ToString() + " " + data_values[3].ToString() + " ");
            weathers.Add(new Weather(data_values[0].ToString(), float.Parse(data_values[1],CultureInfo.InvariantCulture), int.Parse(data_values[2]), int.Parse(data_values[3])));
        }

        
    }
}
