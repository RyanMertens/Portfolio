using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Weather 
{
    public string cityName;
    public float sunPower;
    public int rain;
    public int Snow;


    public Weather(string cn, float sp, int r, int sn)
    {
        cityName = cn;
        sunPower = sp;
        rain = r;
        Snow = sn;
    }
}
