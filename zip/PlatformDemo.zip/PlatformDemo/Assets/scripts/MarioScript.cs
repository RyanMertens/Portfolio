using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MarioScript : MonoBehaviour
{
    // Start is called before the first frame update
    float _speed; //declaration
    float _jumpForce;
    Rigidbody2D _rb2D;
    public GameObject text;

    public bool isGrounded;

    void Start()
    {
        _speed = 3; //initilasation
        _jumpForce = 6;
        _rb2D = GetComponent<Rigidbody2D>();

    
    }

    // Update is called once per frame
    void Update()
    {
       transform.position +=  Vector3.right * Input.GetAxis("Horizontal")*Time.deltaTime * _speed;

      ;

       if (Input.GetKeyDown(KeyCode.Space))
        {
            _rb2D.AddForce(_jumpForce * Vector3.up, ForceMode2D.Impulse);
        }

        



        //_rb2D.AddForce(Vector3.up, ForceMode2D.Impulse);
    }
    void OnTriggerEnter2D(Collider2D col)
    {
        Debug.Log("trigger");
        if (col.CompareTag("coin"))
        {
            
            Destroy(col.gameObject);

        }

        if (col.CompareTag("skull"))
        {
            
            Destroy(gameObject);    
        }

        if (col.CompareTag("peach"))
        {
            Destroy(col.gameObject);
            text.SetActive(true);
        }

    }

    void GroundCheck()
    {
        RaycastHit hit;
        float distance = 1f;
        Vector3 dir = new Vector3(0, -1);
         //bool isGrounded();

        if (Physics.Raycast(transform.position, dir, out hit, distance))
        {
            isGrounded = true;
            Debug.Log("hit");
        }
        else
        {
            isGrounded = false;
            Debug.Log("No hit");
        }
        
    }

    

    
}
