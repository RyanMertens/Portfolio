using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CharacterMovement : MonoBehaviour 
{ 

    public float Speed;
    public float JumpHeight;
    private Rigidbody2D _rigidBody;
  


    // Start is called before the first frame update
    void Start()
    {
        _rigidBody = gameObject.GetComponent<Rigidbody2D>();

    }

    // Update is called once per frame
    void Update()
    {
        // float horizontalInput = horizontalInput.GetAxis("Horizontal");
        // Vector2 moveDir = new Vector2(horizontalInput * Speed * Time.deltaTime, 0);
        /// transform.Translate(moveDir);

        // if (horizontalInput.GetKeyDown(KeyCode.Space))
        // {
        //     Rigidbody2D rb = gameObject.GetComponent<RigidBody2d>();
        //     rb.AddForce(Vector2.up * JumpHeight, ForceMode2D.Impulse);

        transform.Translate(new Vector2(Input.GetAxis("Horizontal") * Speed * Time.deltaTime, 0));

        if (Input.GetKeyDown(KeyCode.Space) && _rigidBody.velocity.y < 0.05f && _rigidBody.velocity.y > -0.05f)
        {
            _rigidBody.AddForce(Vector2.up * JumpHeight, ForceMode2D.Impulse);
        }

    }


    }

