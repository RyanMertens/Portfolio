using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Gun : MonoBehaviour
{
    public AudioSource someSound;

    public GameObject BulletPrefab;

    public GameObject BulletOrigin;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.R))
        {
            someSound.Play();   
            Instantiate(BulletPrefab, BulletOrigin.transform.position, BulletOrigin.transform.rotation);
        }
    }
}
